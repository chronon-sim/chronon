# Validation
Runtime revision: 9a9bd5b. Regression-test revision: 14a79b8.
Release: full CTest suite, --parallel 8 (126 tests).
ASan/UBSan/LeakSanitizer: RelWithDebInfo -O1 -g1 -DNDEBUG, CHRONON_ENABLE_ASAN=ON,
CHRONON_ENABLE_WERROR=ON, ASAN_OPTIONS=detect_leaks=1:halt_on_error=1, 8 clock tests.
LeakSanitizer cannot operate under ptrace; the successful run was outside the sandbox.
TSan: RelWithDebInfo, CHRONON_ENABLE_TSAN=ON, TSAN_OPTIONS=halt_on_error=1,
8 clock/FIFO/recorder tests, --parallel 4.
Native fixtures: scripts/validate_clock_traces.py --directory out/multiclock-142-native
with the pinned Perfetto v57.2 Trace Processor wrapper.
